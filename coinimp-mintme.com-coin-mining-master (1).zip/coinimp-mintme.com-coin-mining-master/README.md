# CoinIMP - MintMe Coin Mining
### ![#00f7ff](https://via.placeholder.com/15/00f7ff/000000?text=+) Example of API integration for MintMe Coin webminer into custom website using CoinIMP as miner service provider


Sample Demo Links :
<br>https://raw.githack.com/marcustansoon/coinimp-mintme.com-coin-mining/master/src/index.html

<br>

<p align="center">
  <img src="https://i.imgur.com/530gDhg.png" width="650" title="CSS Calendar text">
</p>

#### ![#f03c15](https://via.placeholder.com/15/f03c15/000000?text=+) Disclaimer:
This repository is mainly for educational purpose only. Author doesn't affiliated with CoinIMP or any other related platforms
<br>

#### ![#f03c15](https://via.placeholder.com/15/f03c15/000000?text=+) Monero Mining Discontinuation: 
*Unfortunately, in-browser Monero mining is no longer supported in CoinIMP*
